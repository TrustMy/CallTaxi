package com.trust.shengyu.rentalcarclient.tools.interfaces;

import android.location.Location;

/**
 * Created by Trust on 2017/8/22.
 */

public interface LocationInterface {
    void getLocation(Location location);
}
